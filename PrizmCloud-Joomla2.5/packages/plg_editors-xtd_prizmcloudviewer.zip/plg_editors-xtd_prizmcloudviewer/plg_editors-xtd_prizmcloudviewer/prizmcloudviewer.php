<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Editors-xtd.prizmcloudviewer
 *
 * @copyright   Copyright (C) 2013 Accusoft Corporation. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/**
 * Editor PrizmCloud Viewer button
 *
 * @package     Joomla.Plugin
 * @subpackage  Editors-xtd.prizmcloudviewer
 * @since       2.5
 */
class PlgButtonPrizmcloudviewer extends JPlugin
{
	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param 	object $subject The object to observe
	 * @param 	array  $config  An array that holds the plugin configuration
	 * @since 1.5
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$this->loadLanguage();
	}

	/**
	 * Display the button
	 *
	 * @return array A two element array of (imageName, textToInsert)
	 */
	public function onDisplay($name)
	{
		JHtml::_('behavior.modal');
		
		$app     = JFactory::getApplication();
		$doc 	 =& JFactory::getDocument();
		$appname = $app->getName();
		$apppath = $appname == 'site' ? '' : '../';
		$link = $apppath . 'plugins/editors-xtd/prizmcloudviewer/prizmcloudviewer-dialog.php?app='.$appname.'&amp;e_name='.$name;
		
		/*$css = ".button2-left .prizmcloud {
			background:url(../images/j_button2_pagebreak.png) 100% 0 no-repeat;
		$doc->addStyleDeclaration($css);*/

		$button = new JObject;
		$button->modal = true;
		$button->link  = $link;
		$button->text  = JText::_('PrizmCloud Viewer');
		$button->name  = 'pagebreak';
		$button->options = "{handler: 'iframe', size: {x: 500, y: 400}}";

		return $button;
	}
}
