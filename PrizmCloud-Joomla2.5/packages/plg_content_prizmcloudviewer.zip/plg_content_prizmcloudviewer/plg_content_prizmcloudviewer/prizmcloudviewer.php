<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Content.prizmcloudviewer
 *
 * @copyright   Copyright (C) 2013 Accusoft Corporation. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

jimport('joomla.utilities.utility');

/**
 * PrizmCloud Embedded Document Viewer plugin
 *
 * @package     Joomla.Plugin
 * @subpackage  Content.prizmcloudviewer
 */
class PlgContentPrizmcloudviewer extends JPlugin
{
	/**
	 * Load the language file on instantiation.
	 *
	 * @var    boolean
	 * @since  2.5
	 */
	protected $autoloadLanguage = true;
	
	/**
	 * iframe base url path
	 */
	protected $basepath = 'http://connect.ajaxdocumentviewer.com/?key=';

	/**
	 * @param   string	The context of the content being passed to the plugin.
	 * @param   object	The article object.  Note $article->text is also available
	 * @param   object	The article params
	 * @param   integer  The 'page' number
	 *
	 * @return  void
	 * @since   1.6
	 */
	public function onContentPrepare($context, &$article, &$params, $page = 0)
	{
		$canProceed = $context == 'com_content.article';
		if (!$canProceed) { return; }

		// Simple performance check to determine whether bot should process further.
		if (JString::strpos($article->text, '{PrizmCloud-viewer') === false) { return true; }
		
		// Expression to search for.
		$regex = '#{PrizmCloud-viewer(.*)?}#iU';

		// Find all instances of plugin and put in $matches.
		$matches = array();
		preg_match_all($regex, $article->text, $matches, PREG_SET_ORDER);
		
		// No matches, skip this
		if ($matches)
		{
			foreach ($matches as $match) 
			{
				$this->_buildandInsertIframe(&$article, $match, $regex, $params);
			}
		}
	}
	
	/**
	 * Builds html iframe for viewer
	 */
	private function _buildandInsertIframe(&$article, $match, $regex, $params)
	{
		if($this->params->get('prizmcloud_key'))
		{
			$url_base = 'http://connect.ajaxdocumentviewer.com/?key=';
			$rand     = rand();
			$pkey     = $this->params->get('prizmcloud_key');
			
			// split string into associative array with key,value pairs
			preg_match_all('/([a-zA-Z0-9_]+)=("\s*([^"]*)\s*")\s*/', trim($match[1]), $pairs);
			$data = array_combine($pairs[1], $pairs[3]);
			
			// build iframe src url
			$type    = (array_key_exists('vtype', $data) && !empty($data['vtype'])) ? $data['vtype'] : '';
			$doc_url = (array_key_exists('doc_url', $data) && !empty($data['doc_url'])) ? $data['doc_url'] : '';
			$width   = (array_key_exists('vwidth', $data) && !empty($data['vwidth'])) ? $data['vwidth'] : '';
			$height  = (array_key_exists('vheight', $data) && !empty($data['vheight'])) ? $data['vheight'] : '';
			$iwidth  = (!empty($width)) ? '&viewerwidth=' . $width : '';
			$iheight = (!empty($height)) ?'&viewerheight=' . $height : '';
			$width   = ($width) ? ($width + 20) : '';
			$height   = ($height) ? ($height + 20) : '';
			$print   = (array_key_exists('print_button', $data) && !empty($data['print_button'])) ? $data['print_button'] : '';
			$color   = (array_key_exists('toolbar_color', $data) && !empty($data['toolbar_color'])) ? '&toolbarColor=' . $data['toolbar_color'] : '';
			$url     = $url_base . $pkey . '&viewertype=' . $type . '&document=' . $doc_url . $iheight . $iwidth .  '&printButton=' . $print . $color;
			$html    = '<div class="prizmcloud_viewer_frame"><iframe src="' .$url .'" width="' . $width .'" height="' . $height . '" class="prizmcloud-viewer" id="prizm_docs_iframe_' . $rand .'" seamless></iframe></div>';

			$article->text = str_replace( $match[0], $html, $article->text );
			
		}
		else
		{
			$html = '<p class="alert alert-notice">Please sign up for an account to use PrizmCloud Docs Viewer. If you already signed up, add your key by logging into the admin section and navigating to the Plugin Manager. <a href="http://prizmcloud.accusoft.com/register.html" target="_blank" title="PrizmCloud ">Prizm Cloud Sign Up</a></p>';
			$article->text = str_replace( $match[0], $html, $article->text );
		}
	}
}